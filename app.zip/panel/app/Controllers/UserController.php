<?php

namespace App\Controllers;

use App\Models\Users;
use Respect\Validation\Validator as v;

class UserController
{
    public function createUser($request, $response)
    {
        // گرفتن داده‌های ورودی
        $data = $request->getParsedBody();

        // ولیدیشن داده‌ها
        $usernameValidator = v::alnum()->noWhitespace()->length(3, 20);
        $passwordValidator = v::length(6, 20);

        if (!$usernameValidator->validate($data['username']) || !$passwordValidator->validate($data['password'])) {
            return $response->withJson(['error' => 'Invalid data provided'], 400);
        }

        // ایجاد کاربر جدید
        $userModel = new Users();
        $user = $userModel->createUser([
            'username' => $data['username'],
            'password' => password_hash($data['password'], PASSWORD_BCRYPT),
            'email' => $data['email'] ?? null,
            'mobile' => $data['mobile'] ?? null,
            'status' => 'active'
        ]);

        if ($user) {
            return $response->withJson(['success' => 'User created successfully'], 201);
        } else {
            return $response->withJson(['error' => 'Failed to create user'], 500);
        }
    }
}
