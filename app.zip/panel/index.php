<?php

/**
 * By RocketAp
 * Github: https://github.com/rocket-ap
 */

define('PATH', __DIR__);


require_once 'vendor/autoload.php';
require_once 'bootstrap/bootstrap.php';
